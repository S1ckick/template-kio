rm *.aux
rm *.bbl
rm *.blg
rm *.log
rm *.out
rm main.pdf
rm main-en.pdf
rm *-clones.bib